package com.example.tela_inicial;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ListView;

import com.example.tela_inicial.CRUD.UsuarioDAO;

import java.util.List;

public class ProdutosActivity extends AppCompatActivity {

    private ListView listView;
    private Button bt_voltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produtos);

        listView= findViewById(R.id.listProduto);
        bt_voltar= findViewById(R.id.bt_voltar);

    }


    public void voltar(View view){
        Intent i = new Intent(ProdutosActivity.this , LoginActivity.class);
        startActivity(i);
    }



}
