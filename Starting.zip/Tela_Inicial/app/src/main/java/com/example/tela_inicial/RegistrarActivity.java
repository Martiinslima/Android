package com.example.tela_inicial;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.tela_inicial.CRUD.UsuarioDAO;

public class RegistrarActivity extends Activity {

    private Button btCadastrar;
    private EditText nome;
    private EditText email;
    private EditText senha;
    private EditText senha2;
    private UsuarioDAO dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);

        btCadastrar = findViewById(R.id.bt_reg_registrar);
        nome = findViewById(R.id.et_reg_username);
        email = findViewById(R.id.et_reg_email);
        senha = findViewById(R.id.et_reg_password);
        senha2 = findViewById(R.id.et_reg_password2);
        dao = new UsuarioDAO(this);
    }
    public void voltar (View view){
        Intent i = new Intent(RegistrarActivity.this , MainActivity.class);
        startActivity(i);
    }


    public void salvar (View view){
        Usuario u = new Usuario();
        u.setNome(nome.getText().toString());
        u.setEmail(email.getText().toString());
        u.setSenha(senha.getText().toString());
        long id = dao.insereUsuario(u);
        Toast.makeText(this, "Usuario inserido com id: " + id, Toast.LENGTH_SHORT).show();

    }
}