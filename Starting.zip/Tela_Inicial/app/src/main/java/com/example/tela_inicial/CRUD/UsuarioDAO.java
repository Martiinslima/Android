package com.example.tela_inicial.CRUD;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.tela_inicial.Usuario;

public class UsuarioDAO {

    private SQLiteDatabase banco;
    private Conexao conexao;

    public UsuarioDAO(Context context) {
        conexao = new Conexao(context);
        banco = conexao.getWritableDatabase();
    }



    public long insereUsuario(Usuario usuario) {

        ContentValues values = new ContentValues();
        values.put("nome", usuario.getNome());
        values.put("email", usuario.getEmail());
        values.put("senha", usuario.getSenha());
        return banco.insert("usuario" , null , values);

    }


}



