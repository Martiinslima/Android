package com.example.tela_inicial.CRUD;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Conexao extends SQLiteOpenHelper {


    private static final String nome_db = "banco.db";
    private static final int versao = 5;
    private static final String TABELA = "usuario";
    private static final String ID = "_id";
    private static final String NOME = "nome";
    private static final String EMAIL = "email";
    private static final String SENHA = "senha";


    public Conexao(Context context)
    {
       super(context, nome_db, null, versao);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE "+TABELA+"("
                + ID + " Integer primary key autoincrement,"
                + NOME + " text ,"
                + EMAIL + " text,"
                + SENHA + " text"
                +")";
        db.execSQL(sql);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABELA);
        onCreate(db);
    }

    /*public String validarLogin (String nome , String senha) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM usuario WHERE nome=? AND senha=?", new String[]{nome, senha});
        if (c.getCount() > 0) {
            return "OK";
        }
        return "ERRO";
    }
    */
}
