package com.example.tela_inicial;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.tela_inicial.CRUD.Conexao;
import com.example.tela_inicial.CRUD.UsuarioDAO;

public class LoginActivity extends AppCompatActivity {

    EditText et_username, et_password;
    Button bt_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        et_username= (EditText) findViewById(R.id.et_reg_username);
        et_password= (EditText)findViewById(R.id.et_password);

        bt_login = (Button)findViewById(R.id.bt_login);

    }
    public void voltar(View view){
        Intent i = new Intent(LoginActivity.this , MainActivity.class);
        startActivity(i);
    }


    public void login (View view){
        if (et_username.getText().toString().equals("usuario") && et_password.getText().toString().equals("usuario")){

            Intent i = new Intent(LoginActivity.this , ProdutosActivity.class);
            startActivity(i);
        }
        else{
            Toast.makeText(this, "Erro.", Toast.LENGTH_SHORT).show();
        }
    }
}



/*
 bt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = et_username.getText().toString();
                String senha = et_password.getText().toString();


                if(nome.equals("")){
                    Toast.makeText(LoginActivity.this, "Usuario não inserido", Toast.LENGTH_SHORT).show();
                }
                else if (senha.equals("")){
                    Toast.makeText(LoginActivity.this, "Senha não inserida", Toast.LENGTH_SHORT).show();
                }
                else{

                    String rs = UsuarioDAO.validarLogin(nome,senha);

                    if (rs.equals("OK")){
                        Toast.makeText(LoginActivity.this, "Login OK", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(LoginActivity.this, "Login errado, tente novamente", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
 */